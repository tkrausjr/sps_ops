<?php


import('Dataface/FormTool/file.php');
/**
 * @ingroup widgetsAPI
 */
class Dataface_FormTool_webcam extends Dataface_FormTool_file {}
