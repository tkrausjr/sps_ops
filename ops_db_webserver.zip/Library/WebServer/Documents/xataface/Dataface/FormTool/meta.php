<?php
import('Dataface/FormTool/hidden.php');
/**
 * @ingroup widgetsAPI
 */
class Dataface_FormTool_meta extends Dataface_FormTool_hidden {}

