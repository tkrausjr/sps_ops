(function(){
	
	
	/**
	 * A test class.
	 * @param {Class2} inputclass The input class.
	 * @param {Class3} inputclass2 The 2nd input class.
	 */
	function MyClass(o){
	
	
	}
	
	
	/**
	 * This is a test function.
	 * @variant 1 First variant only takes one parameter
	 * @param 1 {MyClass} p1 The first myclass parameter.
	 * @returns {void}
	 *
	 * @variant 2 Second variant takes 2 parameters.
	 * @param 1 {String} p1 The name of the parameter.
	 * @param 2 {MyClass} p2 The myclass named parameter.
	 * @returns {int} The value computed.
	 */
	function myfunc(p1, p2){
	
	
	}
	
})();