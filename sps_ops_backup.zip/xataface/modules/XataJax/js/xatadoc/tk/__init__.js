//require <xatadoc/__init__.js>
(function(){

	/**
	 * @package
	 */
	xatadoc.tk = {};
})();