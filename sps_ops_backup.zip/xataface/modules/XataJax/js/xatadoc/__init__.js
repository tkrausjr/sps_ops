/**
 * @package
 */
var xatadoc = {};
