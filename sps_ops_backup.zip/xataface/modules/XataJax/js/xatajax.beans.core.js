//require <xatajax.core.js>
(function(){
	
	/**
	 * @package
	 */
	XataJax.beans = {};
})();