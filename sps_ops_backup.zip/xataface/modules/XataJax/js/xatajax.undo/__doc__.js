//require <xatajax.undo/UndoManager.js>
//require <xatajax.undo/UndoableEditSupport.js>