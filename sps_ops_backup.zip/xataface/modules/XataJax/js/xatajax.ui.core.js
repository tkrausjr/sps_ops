//require <jquery.packed.js>
//require <xatajax.core.js>
//require <jquery-ui.min.js>
/**
 * @package
 */
XataJax.ui = {};
