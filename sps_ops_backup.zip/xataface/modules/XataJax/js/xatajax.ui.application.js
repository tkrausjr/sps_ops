//require <xatajax.ui.core.js>
//require-css <xatajax.ui.application.css>

(function(){

	XataJax.ui.application = {};
	XataJax.ui.application.Application = Application;
	
	

	function Application(o){
		
	}
	
	
	//include <xatajax.ui.application/Tool.js>
	//include <xatajax.ui.application/ToolGroup.js>
	//include <xatajax.ui.application/ToolBar.js>
	//include <xatajax.ui.application/Container.js>
	//#include <xatajax.ui.application/Document.js>
	
	

})();