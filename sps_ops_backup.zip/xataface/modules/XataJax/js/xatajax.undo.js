(function(){
	/**
	 * @package
	 */
	XataJax.undo = {};
})();