(function(){

	function Serializable(o){
	
		XataJax.publicAPI(this, {
			serialize: serialize,
			unserialize: unserialize
		});
		
		function serialize(o){
		
		}
		
		function unserialize(o){
			
		}
		
	}

})();

