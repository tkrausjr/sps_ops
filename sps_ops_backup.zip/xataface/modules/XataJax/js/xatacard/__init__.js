var xatacard;

/**
 * @package
 */
xatacard = {};