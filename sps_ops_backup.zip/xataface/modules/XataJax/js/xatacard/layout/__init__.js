//require <xatacard/__init__.js>
(function(){
	/**
	 * @package
	 */
	xatacard.layout = {};
})();	