//require <xatacard/layout/__init__.js>
(function(){

	/**
	 * @package
	 */
	xatacard.layout.io = {};
})();