//require <xatacard/layout/__init__.js>
(function(){
	
	var $ = jQuery;
	
	function Layout(o){
	
		
		
		
		function readObject(o){
			
		}
	}
	
})();