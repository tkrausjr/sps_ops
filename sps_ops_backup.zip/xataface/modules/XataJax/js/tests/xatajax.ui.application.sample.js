//require <tests/ComponentTest.js>
(function(){
	var $ = jQuery;
	$(document).ready(function(){
		//var container = new XataJax.ui.application.Container();
		//$('body').append(container.getElement());
		
		
	});
})();