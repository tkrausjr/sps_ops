//require <xatajax.ui.core.js>
(function(){

	/**
	 * @package
	 */
	XataJax.ui.tk = {};
	

})();