(function(){
	XataJax.ui.designer.DesignElement = DesigElement;
	
	function DesignElement(o){
		XataJax.extend(this, new Object());
		
		var members = {
			
		};
	}
})();