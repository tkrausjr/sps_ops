//require <xatajax.ui.core.js>
(function(){
	XataJax.ui.designer = {};
	
})();