<?php /* Smarty version 2.6.18, created on 2017-01-29 22:58:30
         compiled from global_header.html */ ?>
